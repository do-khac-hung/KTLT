#include <string>
using namespace std;

bool KiemTraSDT(string s);

bool KiemTraEmail(string s);

bool KiemTraGio(int h, int m);

int KiemTraNgay(int dd, int mm, int yy);

void SoNgayTrongThang(int yy, int mm, int a[]);

int KiemTraNam(int yy, int mm);

int DemSoNV(NodeNV* Head);

bool KiemTraNgayHomSau(string a, string a1, string b, string b1, string c, string c1);
