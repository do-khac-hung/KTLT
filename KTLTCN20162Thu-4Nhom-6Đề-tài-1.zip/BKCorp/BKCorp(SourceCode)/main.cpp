﻿#include <iostream>
#include <fstream>
#include <conio.h>
#include <windows.h>
#include <string>
#include "Mylib.h"
#include "Myfunction.h"

using namespace std;

int main()
{
	NodeNV* Head = new NodeNV(); // danh sách liên kết lưu trữ toàn bộ Nhân Viên
	NodeCT* HeadCT = new NodeCT(); // danh sách liên kết lưu trữ các công ty con
	Init(Head, HeadCT);
	readInput(Head, HeadCT, "NV.txt");
	string iLuaChon;
	do
	{
		system("cls");
		Menu();
		cin >> iLuaChon;
		if (iLuaChon == "1")
			Function1(Head, HeadCT);
		else if (iLuaChon == "2")
			Function2(Head, HeadCT);
		else if (iLuaChon == "3")
			Function3(Head, HeadCT);
		else if (iLuaChon == "4")
			Function4(Head, HeadCT);
		else if (iLuaChon == "5")
			Function5(Head, HeadCT);
		else if (iLuaChon == "6")
			Function6(Head, HeadCT);
		else if (iLuaChon == "7")
			break;
	} while (1);
	system("pause");
	return 0;
}