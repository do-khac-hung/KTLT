﻿#include <iostream>
#include <fstream>
#include <conio.h>
#include <windows.h>
#include <string>
#include "Mylib.h"

/* Đọc dữ liệu từ file text*/
void readInput(NodeNV* Head, NodeCT* HeadCT, string _file)
{
	ifstream f;
	f.open(_file, ios_base::in);
	string data, nextMaNV;
	getline(f, data);
	nextMaNV = "NV2";
	int soluongNV = 1;
	while (!f.eof()) {
		NhanVien* tempNV = new NhanVien();
		getline(f, tempNV->Ho);
		getline(f, tempNV->Ten);
		getline(f, tempNV->Donvi);
		getline(f, tempNV->Chucvu);
		getline(f, tempNV->Ngaysinh);
		getline(f, tempNV->Quequan);
		getline(f, tempNV->Diachi);
		getline(f, tempNV->Email);
		getline(f, tempNV->Sdt);
		getline(f, tempNV->Ngaybd);
		tempNV->songaylam = 0;
		bool stop = false;
		do
		{

			getline(f, data);
			stop = checkEquals(data, nextMaNV);
			if (stop)
			{
				AddNV(Head, tempNV, soluongNV);
				AddCT(HeadCT, tempNV, soluongNV);
				soluongNV++;
				nextMaNV = "NV" + convertInttoString(soluongNV + 1);
			}
			else
			{
				tempNV->day[tempNV->songaylam] = data;
				tempNV->songaylam++;
			}
		} while (!stop);

	}
	f.close();

}