
NodeNV* findMaNV(string MaNV, NodeNV*Head);

