﻿#include <iostream>
#include <fstream>
#include <conio.h>
#include <windows.h>
#include <string>
#include "Mylib.h"

using namespace std;

/* Thêm 1 Nhân Viên vào danh sách của Công ty mà NV đó làm việc*/
void AddCT(NodeCT* HeadCT, NhanVien* tempNV, int Ma)
{
	NodeCT* CurNode = HeadCT->next;
	while (CurNode != HeadCT)
	{
		if (checkEquals(CurNode->tenCT, tempNV->Donvi))
		{
			CurNode->soluongNV++;
			AddNV(CurNode->staff, tempNV, Ma);
			return;
		}
		else
			CurNode = CurNode->next;
	}
	if (CurNode == HeadCT)
	{
		NodeCT* newNode = new NodeCT();
		newNode->tenCT = tempNV->Donvi;
		newNode->soluongNV = 1;
		NodeNV* temp = new NodeNV();
		temp->next = temp;
		temp->prev = temp;
		newNode->staff = temp;
		AddNV(newNode->staff, tempNV, Ma);
		newNode->next = CurNode;
		newNode->prev = CurNode->prev;
		CurNode->prev = newNode;
		(newNode->prev)->next = newNode;
	}
}