﻿#include <string>
using namespace std;
typedef struct tagNhanVien
{
	string MaNV;
	string Ho;
	string Ten;
	string Donvi;
	string Chucvu;
	string Ngaysinh;
	string Quequan;
	string Diachi;
	string Email;
	string Sdt;
	string Ngaybd;
	int songaylam;
	string day[31];
} NhanVien;

typedef struct tagNodeNV
{
	NhanVien * nv;
	struct tagNodeNV* next;
	struct tagNodeNV* prev;
} NodeNV;

typedef struct tagNodeCT
{
	string tenCT;
	int soluongNV;
	NodeNV* staff;
	struct tagNodeCT* next;
	struct tagNodeCT* prev;
} NodeCT;


/* Khởi tạo các danh sách liên kết lưu trữ nhân viên*/
void Init(NodeNV* Head, NodeCT* HeadCT);

/* Đọc dữ liệu từ file text*/
void readInput(NodeNV* Head, NodeCT* HeadCT, string _file);

/* Chuyển 1 số sang 1 xâu tương ứng*/
string convertInttoString(int number);

/*Chuyển sâu xang số*/
int convertStringtoInt(string s);

/* Chuyển tất cả kí tự in hoa sang in thường*/
string toLower(string str);

/* Thêm 1 Nhân Viên vào danh sách Nhân Viên*/
void AddNV(NodeNV* Head, NhanVien* tempNV, int Ma);

/* Thêm 1 Nhân Viên vào danh sách của Công ty mà NV đó làm việc*/
void AddCT(NodeCT* HeadCT, NhanVien* tempNV, int Ma);

/* Kiểm tra 2 xâu có bằng nhau không*/
bool checkEquals(string s1, string s2);

/* In ra thông tin của Nhân Viên*/
void printStaffInfo(NhanVien* staff);

/* In ra thông tin của 1 công ty con (phòng ban)*/
void printComanyInfo(NodeCT* CT);

/* Bảng chọn chức năng*/
void Menu();

/*Kiểm tra tenNV với  họ tên của các Nhân Viên*/
bool findStaffName(string tenNV, NhanVien* staff);

