﻿#include <iostream>
#include <fstream>
#include <conio.h>
#include <windows.h>
#include <string>
#include "Mylib.h"
#include "Myfunction.h"
using namespace std;

void Function2(NodeNV* Head,NodeCT* HeadCT)
{
	system("cls");
	string tenNV;
	cout << "Nhap vao ho ten NV can tim: " << endl;
	cout << "Nhap: ";
	cin.ignore();
	getline(cin, tenNV);
	cout << "Cac Nhan vien khop voi tim kiem : " << endl << endl;
	bool hasStaff = false;
	for (NodeNV* node_i = Head->next; node_i != Head;
		node_i = node_i->next)
	{
		if (findStaffName(tenNV, node_i->nv)) // Kiểm tra tên của các NV có chứa tenNV 
		{
			hasStaff = true;
			printStaffInfo(node_i->nv);
		}
	}
	if (!hasStaff)
		cout << "Khong co Nhan vien nao khop voi tim kiem tren" << endl;
	system("pause");
}

/*Kiểm tra tenNV với  họ tên của các Nhân Viên*/
bool findStaffName(string tenNV, NhanVien* staff)
{
	/* Nếu tenNV nằm trong xâu Str là Họ tên của NV thì trả về true*/
	tenNV = toLower(tenNV);
	string Str = staff->Ho + " " + staff->Ten;
	Str = toLower(Str);
	if (Str.find(tenNV, 0) != -1)
		return true;
	else
		return false;
}