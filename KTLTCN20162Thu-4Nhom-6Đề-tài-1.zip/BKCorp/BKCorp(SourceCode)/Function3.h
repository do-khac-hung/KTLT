﻿struct Time
{
	int day, month, year;
	int giobd, phutbd;
	int giokt, phutkt;
};

struct Clock
{
	int hour, minute;
};

/* Kiểm tra maNV trong danh sách NV của công ty*/
NodeNV* findMaNV(string MaNV, NodeNV*Head);

/*Kiểm tra maNV nhập vào có đúng không*/
bool checkMaNV(string s);

/*Đọc vào maNV cho tới khi user nhập vào đúng*/
string docMaNV();

/*Đa năng hóa toán tử - cho clock*/
Clock operator - (Clock clock1, Clock clock2);

/* Tạo 1 Clock mới với tham số truyền vào*/
Clock setClock(int _gio, int _phut);

/* Tạo 1 Time mới với tham số truyền vào*/
Time setTime(int _day, int _month, int _year, int _giobd, int _phutbd, int _giokt, int _phutkt);

/* Lấy thời gian từ các ngày làm việc của NV đưa vào 1 cấu trúc Time*/
Time getTime(string s);

/* ngày đi muộn của NV*/
void NgayDiMuon(NhanVien* staff);

/* Đếm số ngày nghỉ trong tháng*/
int DemSoNgayNghi(int _month, int _year);

/*Chuyển sâu xang số*/
int convertStringtoInt(string s);