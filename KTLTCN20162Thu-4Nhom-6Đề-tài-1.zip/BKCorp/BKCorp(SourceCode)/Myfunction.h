﻿#include <string>
using namespace std;

/*Các chức năng của bài*/
void Function1(NodeNV* Head, NodeCT* HeadCT);
void Function2(NodeNV* Head, NodeCT* HeadCT);
void Function3(NodeNV* Head, NodeCT* HeadCT);
void Function4(NodeNV* Head, NodeCT* HeadCT);
void Function5(NodeNV* Head, NodeCT* HeadCT);
void Function6(NodeNV* Head, NodeCT* HeadCT);
