﻿#include <iostream>
#include <fstream>
#include <conio.h>
#include <windows.h>
#include <string>
#include "Mylib.h"
#include "Myfunction.h"
#include "Function5.h"
#include "Function3.h"
#include <algorithm>
#include <ctime>

/*ham them nhan vien moi*/
void Function5(NodeNV *Head, NodeCT* HeadCT)
{
	system("cls");
	string dd, mm, yy, dd1, mm1, yy1, Email;
	int x, y, z;
	int n;
	int h, m, h1, m1;
	int a[13];
	string ngayHomSau;
	NhanVien *nv = new NhanVien();
	nv->songaylam = 0;
	cout << "Chung toi se cung cap ma nhan vien cho ban! \n";
	cin.ignore();
	string Ho, Ten;
	cout << "Nhap vao Ho + Ten Dem Nhan Vien: ";
	getline(std::cin, Ho);
	std::transform(Ho.begin(), Ho.end(), Ho.begin(), ::toupper);/*Chuyển chuỗi về chữ in hoa(Đầu vào,cuối,kết quả)*/
	nv->Ho = Ho;
	cout << "\n";
	cout << "Nhap vao Ten Nhan Vien: ";
	getline(std::cin, Ten);
	std::transform(Ten.begin(), Ten.end(), Ten.begin(), ::toupper);/*Đầu vào,cuối,kết quả*/
	nv->Ten = Ten;
	cout << "\n";
	cout << "Nhap vao Ten Cong Ty: ";
	getline(std::cin, nv->Donvi);
	cout << "\n";
	cout << "Nhap vao Chuc Vu nhan Vien: ";
	getline(std::cin, nv->Chucvu);
	cout << "\n";
	cout << "Nhap Ngay Thang Nam sinh(4 chu so) (Cach nhau boi dau cach): ";
	cin >> dd >> mm >> yy;
	cout << "\n";
	/*chuyen doi kieu string sang int cho 3 chuoi dd-mm-yy*/
	x = atoi(dd.substr(0, 2).c_str());
	y = atoi(mm.substr(0, 2).c_str());
	z = atoi(yy.substr(0, 4).c_str());
	while (y<0 || y>12 || z <= 1) {/*Kiem tra nam sinh co hop le*/
		cout << "Co ve nhu ban da nhap sai .Thang. hoac .Nam. roi !Moi nhap lai! \n";
		cout << "Nhap Ngay Thang Nam (Cach nhau boi dau cach): ";
		cin >> dd >> mm >> yy;
		cout << "\n";
		x = atoi(dd.substr(0, 2).c_str());
		y = atoi(mm.substr(0, 2).c_str());
		z = atoi(yy.substr(0, 4).c_str());
	}
	while (KiemTraNgay(x, y, z) != 1) {/*Kiem tra ngay trong thang co dung hay ko*/
		cout << "Co ve nhu ban da nhap sai .Ngay. trong .Thang. roi! Moi nhap lai! \n";
		cout << "Nhap Ngay Thang Nam (Cach nhau boi dau cach): ";
		cin >> dd >> mm >> yy;
		cout << "\n";
		x = atoi(dd.substr(0, 2).c_str());
		y = atoi(mm.substr(0, 2).c_str());
		z = atoi(yy.substr(0, 4).c_str());
	}
	cout << "Ban nhap dung roi ! \n";
	string NgaySinh = dd + "/" + mm + "/" + yy;
	nv->Ngaysinh = NgaySinh;
	cin.ignore();
	cout << "Nhap vao Que Quan : ";
	getline(std::cin, nv->Quequan);
	cout << "\n";
	cout << "Nhap vao Dia Chi : ";
	getline(std::cin, nv->Diachi);
	cout << "\n";
	cout << "Nhap vao Email : ";
	getline(cin, Email);
	cout << "\n";
	while (KiemTraEmail(Email) == false) {/*kiem tra email nhap vao co dung hay ko?*/
		cout << "Email khong hop le ! Moi nhap lai! \n";
		cout << "Nhap vao Email :";
		getline(cin, Email);
		cout << "\n";
		KiemTraEmail(Email);
	}
	nv->Email = Email;
	cout << "Nhap vao So Dien Thoai : \n";/*kiem tra so dien thoai nhap vao co dung hay ko?*/
	getline(cin, nv->Sdt);
	while (KiemTraSDT(nv->Sdt) == false) {
		cout << "So dien thoai khong hop le ! Moi nhap lai! \n";
		getline(cin, nv->Sdt);
	}
	cout << "Nhap Ngay Thang Nam(4 chu so) bat dau lam viec (Cach nhau boi dau cach): ";
	cin >> dd >> mm >> yy;
	cout << "\n";
	x = atoi(dd.substr(0, 2).c_str());
	y = atoi(mm.substr(0, 2).c_str());
	z = atoi(yy.substr(0, 4).c_str());
	while (y<0 || y>12 || z <= 1) {
		cout << "Co ve nhu ban da nhap sai .Thang. hoac .Nam. roi! Moi nhap lai! \n";
		cout << "Nhap Ngay Thang Nam (Cach nhau boi dau cach): ";
		cin >> dd >> mm >> yy;
		cout << "\n";
		x = atoi(dd.substr(0, 2).c_str());
		y = atoi(mm.substr(0, 2).c_str());
		z = atoi(yy.substr(0, 4).c_str());
	}
	while (KiemTraNgay(x, y, z) != 1) {
		cout << "Co ve nhu ban da nhap sai .Ngay. trong .Thang. roi!Moi nhap lai! \n";
		cout << "Nhap Ngay Thang Nam (Cach nhau boi dau cach): ";
		cin >> dd >> mm >> yy;
		cout << "\n";
		x = atoi(dd.substr(0, 2).c_str());
		y = atoi(mm.substr(0, 2).c_str());
		z = atoi(yy.substr(0, 4).c_str());
	}
	cout << "Ban nhap dung roi ! \n";
	string ngayBD = dd.substr(0, 2) + "/" + mm.substr(0, 2) + "/" + yy.substr(0, 4);
	nv->Ngaybd = ngayBD;
	cin.ignore();
	cout << "Ban di lam duoc may ngay roi : ";
	cin >> n;
	cout << "\n";
	cout << "Ngay thu 1 di lam luc may gio(gio phut) :";
	cin >> h >> m;
	while (KiemTraGio(h, m) == false) {
		cout << "nhap lai! \n";
		cin >> h >> m;
	}
	cout << "Ngay thu 1 tan lam luc may gio(gio phut) :";
	cin >> h1 >> m1;
	while (KiemTraGio(h1, m1) == false) {
		cout << "nhap lai! \n";
		cin >> h1 >> m1;
	}
	string ngayDiLam = ngayBD + "," + convertInttoString(h) +
		":" + convertInttoString(m) + "," + convertInttoString(h1) + ":" + convertInttoString(m1);
	nv->day[nv->songaylam] = ngayDiLam;
	nv->songaylam++;
	for (int i = 2; i <= n; i++) {
		dd1 = dd; mm1 = mm; yy1 = yy;
		cout << "Nhap Ngay di lam thu " << i << " (phai sau ngay di lam thu " << i - 1 << " ): ";
		cin >> dd >> mm >> yy;
		//KiemTraNgayHomSau(dd1, dd, mm1, mm, yy1, yy);
		while (KiemTraNgayHomSau(dd1, dd, mm1, mm, yy1, yy) == false) {
			cout << "Ban nhap sai roi !Moi nhap lai! \n";
			cout << "Nhap Ngay di lam thu " << i << " (phai sau ngay di lam thu " << i - 1 << " ):";
			cin >> dd >> mm >> yy;
		}
		cout << "Ngay thu " << i << " di lam luc may gio(gio phut) :";
		cin >> h >> m;
		while (KiemTraGio(h, m) == false) {
			cout << "\nNhap sai roi! moi nhap lai: ";
			cin >> h >> m;
		}
		cout << "\n";
		cout << "Ngay thu " << i << " tan lam luc may gio(gio phut) :";
		cin >> h1 >> m1;
		cout << "\n";
		while (KiemTraGio(h1, m1) == false) {
			cout << "Nhap sai roi! moi nhap lai: ";
			cin >> h1 >> m1;
			cout << "\n";
		}
		ngayHomSau = dd + "/" + mm + "/" + yy;
		ngayDiLam = ngayHomSau + "," + convertInttoString(h) + ":" + convertInttoString(m) + "," + convertInttoString(h1) + ":" + convertInttoString(m1);
		nv->day[nv->songaylam] = ngayDiLam;
		nv->songaylam++;
	}
	int MaNV = DemSoNV(Head);
	MaNV++;
	AddNV(Head, nv, MaNV);
	AddCT(HeadCT, nv, MaNV);
	system("pause");
}

int KiemTraNam(int yy, int mm) {
	bool check;
	if (yy % 400 == 0 || (yy % 4 == 0 && yy % 100 != 0)) {
		check = 0;//Nam nhuan
	}
	else check = 1;//Nam thuong
	return check;
}//Kiem tra nam nhuan hay ko nhuan

void SoNgayTrongThang(int yy, int mm, int a[13]) {
	int i;
	for (i = 1; i <= 12; i++) {
		if (i <= 12 && i != 2)
			if (i % 2 != 0 || i == 8, 10, 12) a[i] = 31;//tháng 1,3,5,7,8,10,12 có 31 ngày
			else a[i] = 30;//tháng 2,4,6 có 30 ngày
			if (i == 2)
				if (KiemTraNam(yy, mm) == 0) a[i] = 29;//Nam nhuan tháng 2 có 29 ngày
				else a[i] = 28;//Nam không nhuan tháng 2 có 28 ngày
	}
}//Xét 1 tháng có bao nhiêu ngày

int KiemTraNgay(int dd, int mm, int yy) {
	bool check;
	int a[13];//Ðat bien luu ngày trong tháng
	SoNgayTrongThang(yy, mm, a);
	if (dd <= a[mm] && dd>0)
		check = 1;//Ðúng
	else check = 0;//Sai
	return check;
}//Kiem tra ngày

 /*kiem tra gio nhap vao*/
bool KiemTraGio(int h, int m)
{
	if (h >= 0 && h<24 && m >= 0 && m<60) {
		return true;
	}
	return false;
}

/*Kiem tra dia chi email nhap vao*/
bool KiemTraEmail(string s)
{

	int a = s.length();
	if (a<4 || s.find("@") == -1 || s.find(".com") == -1 || s.find(" ") != -1) {
		return false;
	}
	return true;
}

/*Kiem tra so dien thoai nhap vao*/
bool KiemTraSDT(string s)
{
	if (s.length()<9 || s.length()>12) {
		return false;
	}
	for (int i = 0; i<s.length(); i++) {
		if (s[i] < 48 || s[i] > 57) {
			return false;
			break;
		}
	}
	return true;
}

/*Dem so nhan vien de them nhan vien co MNV sau nhan vien cuoi cung*/
int DemSoNV(NodeNV* Head)
{
	NhanVien* nv = Head->prev->nv;
	string maNV = nv->MaNV;
	maNV = maNV.substr(2);
	int ma = convertStringtoInt(maNV);
	return ma;
}

/*Kiem tra ngay di lam hom sau co phai sau ngay di lam hom truoc khong?*/
bool KiemTraNgayHomSau(string a, string a1, string b, string b1, string c, string c1)
{
	int m[6] = { 1,3,5,7,8,10 };
	int n[4] = { 4,6,9,11 };
	int x = atoi(a.substr(0, 2).c_str());
	int x1 = atoi(a1.substr(0, 2).c_str());
	int y = atoi(b.substr(0, 2).c_str());
	int y1 = atoi(b1.substr(0, 2).c_str());
	int z = atoi(c.substr(0, 4).c_str());
	int z1 = atoi(c1.substr(0, 4).c_str());
	for (int i = 0; i < 6; i++) {
		if (z1 < z || y != 12 && y1 < y || (x1 <= x && y != 12 && y1 == y))
			return false;
		else if ((y == m[i] && x != 31 && x1 <= x) || ((y == 12) && (x == 31) && (z1 == z))
			|| (y == n[i] && x != 30 && x1 <= x) || (y == 2 && x != 28 && x1 <= x) || (x1 == 1 && y1 == 1 && z1 == z))
			return false;
		else
			return true;
	}
}
