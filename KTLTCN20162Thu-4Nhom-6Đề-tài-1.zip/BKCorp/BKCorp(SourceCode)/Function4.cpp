#include <iostream>
#include <fstream>
#include <conio.h>
#include <time.h>
#include <windows.h>
#include <string>
#include "Mylib.h"
#include "Myfunction.h"

//In nhan vien trong 1 cong ty
void print(NodeCT* CT)
{
	NodeNV* node_i = CT->staff->next;
	cout << CT->tenCT << " co " << CT->soluongNV << " nhan vien" << endl;//In ten cong ty va so luong nhan vien
	cout << "Danh sach nhan vien trong cong ty " << endl << endl;

	//Duyet danh sach vi in ra ket qua
	while (node_i != CT->staff)
	{
		cout << node_i->nv->Ho << " " << node_i->nv->Ten << endl;
		node_i = node_i->next;
	}
	cout << endl << endl;
}
void Function4(NodeNV* Head, NodeCT* HeadCT)
{
	//Khai bao
	system("cls");
	int i = 0;
	float time;
	clock_t start, finish;
	NodeCT* node_i = HeadCT->next;
	string tencongty;

	//Nhap ten cong ty can tim kiem
	cout << "Nhap vao ten Cong Ty can tim : ";
	cin.ignore();
	getline(cin, tencongty);
	tencongty = toLower(tencongty);
	cout << "Cong ty tim kiem : ";
	start = clock();

	//Duyet tu dau danh sach den cuoi de tim kiem
	while (node_i != HeadCT)
	{
		node_i->tenCT = toLower(node_i->tenCT);
		if (tencongty.compare(node_i->tenCT) == 0)
		{
			i++;
			print(node_i);
		}
		node_i = node_i->next;
	}

	//Neu khong tim thay thi in thong bao
	if (i == 0)
	{
		cout << "\nKhong co trong tim kiem\n";
	}
	finish = clock();

	//Tinh thoi gian chay
	time = (float)(finish - start) / CLOCKS_PER_SEC;
	cout << "Thoi gian chay cua tim kiem tuan tu theo nam sinh la: " << time << endl;
	system("pause");
}

