﻿#include <iostream>
#include <fstream>
#include <conio.h>
#include <windows.h>
#include <string>
#include "Mylib.h"
#include "Myfunction.h"
#include "Function3.h"
#include <ctime>

using namespace std;

Clock operator - (Clock clock1, Clock clock2)
{
	Clock clock0;
	int div_minute = 0, div_hour = 0;

	clock0.minute = (clock1.minute - clock2.minute);
	if (clock0.minute < 0)
	{
		div_hour = 1;
		clock0.minute += 60;
	}
	clock0.hour = (clock1.hour - clock2.hour - div_hour);
	return clock0;
}
/* Tạo 1 Clock mới với tham số truyền vào*/
Clock setClock(int _gio, int _phut)
{
	Clock c;
	c.hour = _gio;
	c.minute = _phut;
	return c;
}

/* Tạo 1 Time mới với tham số truyền vào*/
Time setTime(int _day, int _month, int _year, int _giobd, int _phutbd, int _giokt, int _phutkt)
{
	Time t;
	t.day = _day;
	t.month = _month;
	t.year = _year;
	t.giobd = _giobd;
	t.phutbd = _phutbd;
	t.giokt = _giokt;
	t.phutkt = _phutkt;
	return t;
}

/* Lấy thời gian từ các ngày làm việc của NV đưa vào 1 cấu trúc Time*/
Time getTime(string s)
{
	int dem = 0;
	bool fault = false;
	Time defaultTime = setTime(1, 1, 1980, 7, 0, 7, 0);
	int t[7] = { 0,0,0,0,0,0,0 };
	for (int i = 0; i < s.length(); i++)
	{
		char c = s[i];
		if (c == '/' || c == ',' ||
			c == ':')
			dem++;
		else if (c < 48 || c > 57)
			fault = true;
		else
		{
			t[dem] = t[dem] * 10 + (int)c - 48;
		}
	}
	if (fault == true)
	{
		cout << "Co loi khi nhap vao thoi gian." << endl;
		cout << "Thoi gian se duoc tra ve tg mac dinh 1/1/1980,7:00,7:00" << endl;
		return defaultTime;
	}
	else
	{
		Time time = setTime(t[0], t[1], t[2], t[3], t[4], t[5], t[6]);
		for (int i = 0; i < 7; i++)
			return time;
	}
}
/*Chuyển sâu xang số*/
int convertStringtoInt(string s)
{
	int returnvalue = 0;
	for (int i = 0; i < s.length(); i++)
	{
		char c = s[i];
		returnvalue = returnvalue * 10 + (int)c - 48;
	}
	return returnvalue;
}

/* Đếm số ngày nghỉ trong tháng*/
int DemSoNgayNghi(int _month, int _year, int songaydilam)
{
	/* Xem ngày đầu tiên của tháng ý vào thứ mấy biết ngày 1/1/1980 là t3
	* Từ đó biết ngày t7 đầu tiên rồi đếm số ngày t7 CN
	* Ngoài ra đếm xem các ngày lễ trong tháng đó từ file Ngayle.txt*/
	int m[12] = { 31,28,31,30,31,30,31,31,30,31,30,31 };
	if (_year % 4 == 0)
		m[1] = 29;// m[1] la tháng 2 năm nhuận sẽ có 29 ngày
	int c = 0;
	int songay = (_year - 1980) * 365 + (int)(_year - 1980) / 4;
	while (c < _month - 1)
	{
		songay += m[c];
		c++;
	}
	songay++;
	int soNgayNghiLe = 0;
	int thu = (songay % 7 + 3) % 7; // đây là thứ của ngày đầu tiên trong tháng đó
	for (int i = 0; i < m[_month - 1]; i++)
	{
		if (thu == 1 || thu == 7) // thu = 1 tuc CN
			soNgayNghiLe++;
		thu++;
		if (thu == 8)
			thu = 1;
	}
	ifstream file;
	file.open("Ngayle.txt", ios_base::in);
	string data, str;
	while (!file.eof()) {
		getline(file, data);
		str = data.substr(3);
		int temp = convertStringtoInt(str);
		if (temp == _month)
		{
			soNgayNghiLe++;
		}
	}
	file.close();
	return m[_month - 1] - soNgayNghiLe - songaydilam;
}

/* ngày đi muộn của NV và số ngày nghỉ*/
void NgayDiMuon(NhanVien* staff)
{
	int _year, _month;
	for (int i = 0; i < staff->songaylam; i++)
	{
		Time t = getTime(staff->day[i]);
		_year = t.year;
		_month = t.month;
		Clock h1 = setClock(t.giobd, t.phutbd);
		Clock h2 = setClock(t.giokt, t.phutkt);
		Clock h = h2 - h1;
		int soGioDiMuon = 8 - h.hour;
		cout << "Ngay " << t.day << "/" << t.month << "/" << t.year;
		if (soGioDiMuon > 0)
			cout << " di muon : " << soGioDiMuon << " tieng." << endl;
		else
			cout << " khong di muon" << endl;
	}
	cout << "----------------------------------------------------" << endl;
	cout << "Tong so ngay di lam " << staff->songaylam << endl;
	int soNgayNghi = DemSoNgayNghi(_month, _year, staff->songaylam);
	cout << "So ngay nghi  " << soNgayNghi << endl;
}


/*Kiểm tra maNV nhập vào có đúng không*/
bool checkMaNV(string s)
{
	/*maNV phải bắt đầu bằng "NV" và 1 số
	*nếu đúng trả về true sai trả về false*/
	if (s[0] != 'N' && s[1] != 'V')
		return false;
	for (int i = 2; i < s.length(); i++)
	{
		char c = s[i];
		if (c < 48 || c > 57)
			return false;
	}
	return true;
}
/*Đọc vào maNV cho tới khi user nhập vào đúng*/
string docMaNV()
{
	/* Yêu cầu user nhập vào maNV tới khi nhập đúng*/
	string maNV;
	cout << "Nhap vao ma NV (vi du NV2): ";
	while (1)
	{
		cin.ignore();
		cin >> maNV;
		if (checkMaNV(maNV) == false)
			cout << "Ma nhap vao khong dung\nNhap lai: ";
		else return maNV;
	}
}
/* Kiểm tra maNV trong danh sách NV của công ty*/
NodeNV* findMaNV(string MaNV, NodeNV*Head)
{
	/* Nếu có 1 NV có maNV trùng với maNV trên thì trả về nhân viên tương ứng
	* Nếu duyệt hết vẫn không có thì trả về Head*/
	NodeNV *temp = Head->next;
	MaNV = toLower(MaNV);
	while (temp != Head) {
		//if(str.find(MaNV1,0) != -1) break;
		string str = temp->nv->MaNV;
		str = toLower(str);
		if (str.compare(MaNV) == 0)
			return temp;
		temp = temp->next;
	}
	return temp;
}


void Function3(NodeNV* Head, NodeCT* HeadCT)
{
	system("cls");
	string maNV = docMaNV();
	float time;
	clock_t start, finish;
	start = clock();
	NodeNV* temp = findMaNV(maNV, Head);
	if (temp == Head)
	{
		cout << "Khong ton tai maNV nay" << endl;
		system("pause");
		return;
	}
	//int soNgayNghi = DemSoNgayNghi(temp->nv);
	cout << temp->nv->MaNV << endl;
	cout << temp->nv->Ho << " " << temp->nv->Ten << endl;
	NgayDiMuon(temp->nv);
	finish = clock();
	time = (float)(finish - start) / CLOCKS_PER_SEC;
	cout << "Thoi gian thuc hien : " << time << endl;
	system("pause");
}