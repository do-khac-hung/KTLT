﻿#include <iostream>
#include <fstream>
#include <conio.h>
#include <windows.h>
#include <string>
#include "Mylib.h"
#include "Myfunction.h"
#include "Function6.h"
#include "Function3.h"
#include <ctime>
using namespace std;

string insertstring(string T) {
	if (T.length() == 8) {
		T.insert(0, "0");
		T.insert(3, "0");
	}
	if (T.length() == 9) {
		if (atoi(T.substr(0, 1).c_str()) == 0 || T.substr(2, 1) == "/") {
			T.insert(3, "0");
		}
		else {
			T.insert(0, "0");
		}
	}
	return T;
}
string kiemtrangaythangnam(string T) {
	string t = "0";
	int ngay, thang, nam;
	if (T.length() > 10 || T.length()<8) {
		T.erase(0, T.length());
		cout << " \"Ban nhap sai \" " << endl;
		cout << "Moi ban nhap lai : "; cin >> T;
		T = kiemtrangaythangnam(T);
	}
	T = insertstring(T);
	ngay = atoi(T.substr(0, 2).c_str());
	thang = atoi(T.substr(3, 2).c_str());
	nam = atoi(T.substr(6, 4).c_str());
	if ((ngay = 0 || ngay>31) || (thang = 0 || thang>12) || (nam = 0 || nam <1900)) {
		T.erase(0, T.length());
		cout << "\"Ban nhap sai \"" << endl;
		cout << "Moi ban nhap lai : "; cin >> T;
		T = kiemtrangaythangnam(T);
	}
	if ((T[2] != '/') || (T[5] != '/')) {
		T.erase(0, T.length());
		cout << "Ngay thang nam nhap sai(co dang 24/01/1997)" << endl;
		cout << "Moi ban nhap lai : "; cin >> T;
		T = kiemtrangaythangnam(T);
	}
	return T;
}
// kiem tra email,neu khong co @ yeu cau nhap lai
string checkemail(string T) {
	int count = 0;
	for (int i = 0; i<T.length(); i++) {
		if (T[i] == 0x40) {
			count++;
		}
	}
	if (count == 1) {
		return T;
	}
	else {
		T.erase(0, T.length());
		cout << "Ban nhap sai email" << endl; cout << "Moi ban nhap lai : "; cin >> T;
		count = 0;
		checkemail(T);
	}
	return T;

}
//kiem tra sdt, chi chap nhan so
string kiemtrasdt(string T) {
	int count = 0;
	for (int i = 0; i<T.length(); i++) {
		if (T[i] < 48 || T[i] > 57) {
			T.erase(0, T.length());
			count++;
			break;
		}
	}
	if (count != 0) {
		cout << "So dien thoai khong co chu : " << endl;
		cout << "Moi ban nhap lai : "; cin >> T;
		T = kiemtrasdt(T);
	}
	return T;
}


NodeNV* checkMaNV(string MaNV, NodeNV*Head) //MaNV1 lay tu ban phim
{
	NodeNV *tp = Head->next;

	MaNV = toLower(MaNV);
	while (tp != Head) {
		string str = tp->nv->MaNV;
		str = toLower(str);
		if (str.compare(MaNV) == 0)
			return tp;
		tp = tp->next;
	}
	return tp;
}

void Function6(NodeNV* Head, NodeCT* HeadCT) {
	system("cls");
	string MaNV;
	string rong;
	string str = "k";
	char iLuaChon;
	float time1, time2, time3, time4;
	clock_t start1, finish1, start2, finish2, start3, finish3;
	cout << "nhap ma so nhan vien: " << endl;
	MaNV = docMaNV();
	start1 = clock();
	NodeNV *tp = checkMaNV(MaNV, Head);
	finish1 = clock();
	if (tp != Head)
	{
		NhanVien* nv = tp->nv;
		char iLuaChon;
		string Ho, Ten, Donvi, Chucvu, Quequan, Sdt, Ngaybd, Ngaysinh, Diachi, Email;
		string Ho1, Ten1, Donvi1, Chucvu1, Quequan1, Sdt1, Ngaybd1, Ngaysinh1, Diachi1, Email1;
		cout << " nhap thong tin moi de cap nhat, nhap k de giu nguyen thong tin: " << endl;
		// nhap ho
		cout << "Nhap ho nhan vien:" << endl;
		cin.ignore();
		getline(cin, Ho);
		if (Ho.compare(str) != 0) {
			Ho1 = Ho;
		}
		// nhap ten
		cout << "Nhap ten cua nhan vien : " << endl;
		getline(cin, Ten);
		if (Ten.compare(str) != 0) {
			Ten1 = Ten;
		}
		// nhap don vi
		cout << "Nhap don vi cua nhan vien : " << endl;
		getline(cin, Donvi);
		if (Donvi.compare(str) != 0) {
			Donvi1 = Donvi;
		}
		// nhap chuc vu
		cout << "Nhap chuc vu cua nhan vien : " << endl;
		getline(cin, Chucvu);
		if (Chucvu.compare(str) != 0) {
			Chucvu1 = Chucvu;
		}
		// nhap ngay sinh
		cout << "Nhap Ngay sinh cua nhan vien (dd/mm/yyyy): " << endl;
		getline(cin, Ngaysinh);
		Ngaysinh1 = kiemtrangaythangnam(Ngaysinh);
		/*if (Ngaysinh.compare(str) != 0) {
			Ngaysinh1 = Ngaysinh;
		}*/	
		// nhap que quan
		cin.ignore();
		cout << "Nhap que quan  cua nhan vien : " << endl;
		getline(cin, Quequan);
		if (Quequan.compare(str) != 0) {
			Quequan1 = Quequan;
		}
		// nhap dia chi
		cout << "Nhap dia chi cua nhan vien : " << endl;
		
		getline(cin, Diachi);
		if (Diachi.compare(str) != 0) {
			Diachi1 = Diachi;
		}
		// nhap ngay bat dau lam viec
		cout << "Nhap ngay bat dau cua nhan vien (dd/mm/yyyy) : " << endl;
		
		getline(cin, Ngaybd);
		Ngaybd1 = kiemtrangaythangnam(Ngaybd);
		/*if (Ngaybd.compare(str) != 0) {
			Ngaybd1 = Ngaybd;
		}*/
		// nhap so dien thoai,chi cho nhap so
		cin.ignore();
		cout << "Nhap so dien thoai cua nhan vien : " << endl;
		getline(cin, Sdt);
		if (Sdt.compare(str) != 0) {
			Sdt1 = kiemtrasdt(Sdt);
		}
		// nhap email ,kiem tra phai co @ moi chap nhan
		cout << "Ban co muon nhap email cua NV khong (y/n)" << endl;
		cin >> iLuaChon;
		if (iLuaChon == 'y')
		{
			cout << "Nhap email cua nhan vien : ";
			cin.ignore();
			getline(cin, Email);
			Email1 = checkemail(Email);
		}

		start2 = clock();
		// cap nhat cac thong tin co ban khi nhap vao khac ki tu k
		if (Ho1.compare(rong)) {
			nv->Ho = Ho1;
		}
		if (Ten1.compare(rong)) {
			nv->Ten = Ten1;
		}
		if (Chucvu1.compare(rong)) {
			nv->Chucvu = Chucvu1;
		}
		if (Diachi1.compare(rong)) {
			nv->Diachi = Diachi1;
		}
		if (Donvi1.compare(rong)) {
			nv->Donvi = Donvi1;
		}
		if (Quequan1.compare(rong)) {
			nv->Quequan = Quequan1;
		}
		if (Email1.compare(rong)) {
			nv->Email = Email1;
		}
		if (Sdt1.compare(rong)) {
			nv->Sdt = Sdt1;
		}
		if (Ngaybd1.compare(rong)) {
			nv->Ngaybd = Ngaybd1;
		}
		if (Ngaysinh1.compare(rong)) {
			nv->Ngaysinh = Ngaysinh1;
		}
		finish2 = clock();
		//cap nhat ngay di lam cua nhan vien
		int songaylamviec = 0;
		do
		{
			cout << "Ban co muon nhap ngay lam viec cua NV khong (y/n)" << endl;
			cin >> iLuaChon;
			if (iLuaChon == 'y')
			{
				cout << "Nhap vao ngay di lam cua NhanVien(dd/mm/yyyy)" << endl;
				cin.ignore();
				string data;
				getline(cin, data);
				data = kiemtrangaythangnam(data);
				songaylamviec++;
				start3 = clock();
				nv->day[songaylamviec] = data;
				finish3 = clock();
			}
			if (iLuaChon == 'n')
				break;
		} while (1);
		nv->songaylam = songaylamviec;
		printStaffInfo(nv);
	}

	//Tinh thoi gian chay
	time1 = (float)(finish1 - start1) / CLOCKS_PER_SEC;
	time2 = (float)(finish2 - start2) / CLOCKS_PER_SEC;
	time3 = (float)(finish3 - start3) / CLOCKS_PER_SEC;
	time4 = time1 + time2 + time3;
	cout << "Thoi gian chay  la: " << time4 << endl;
	system("pause");
}
