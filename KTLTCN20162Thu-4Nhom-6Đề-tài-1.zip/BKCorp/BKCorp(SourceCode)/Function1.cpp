﻿#include <iostream>
#include <fstream>
#include <conio.h>
#include <windows.h>
#include <string>
#include "Mylib.h"
#include "Myfunction.h"
#include <ctime>
void Function1(NodeNV* Head, NodeCT* HeadCT)
{
	system("cls");
	int i = 0;
	float time;
	clock_t start, finish;
	int soluongNV = 0;
	start = clock();
	for (NodeCT* node_i = HeadCT->next; node_i != HeadCT;
		node_i = node_i->next) // truy cập danh sách công ty 
	{
		cout << "Cong Ty(Phong Ban) : " << node_i->tenCT << endl;
		for (NodeNV* node_j = node_i->staff->next; node_j != node_i->staff;
			node_j = node_j->next) // truy cập danh sách nhân viên của công ty đó
		{
			NhanVien* nv = node_j->nv;
			if (checkEquals(nv->Chucvu, "Chu Tich") == true		||
				checkEquals(nv->Chucvu, "Pho Chu Tich") == true ||
				checkEquals(nv->Chucvu, "Giam Doc") == true		||
				checkEquals(nv->Chucvu, "Pho Giam Doc") == true ||
				checkEquals(nv->Chucvu, "Truong Phong") == true ||
				checkEquals(nv->Chucvu, "Pho Phong") == true)
			{
				cout << nv->Chucvu << " : " << nv->Ho << " " << nv->Ten << endl;
			}
		}
		cout << "        So luong NV trong cong ty: " << node_i->soluongNV << endl;
		cout << "----------------------------------------------------" << endl;
		soluongNV += node_i->soluongNV;
	}
	cout << "\nTong so nhan vien cua cac cong ty la: " << soluongNV << endl;
	cout << "----------------------------------------------------" << endl;

	finish = clock();
	time = (float)(finish - start) / CLOCKS_PER_SEC;
	cout << "Thoi gian thuc hien chuong trinh : " << time << endl;
	system("pause");
}