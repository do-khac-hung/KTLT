#include <iostream>
#include <fstream>
#include <conio.h>
#include <windows.h>
#include <string>
#include "Mylib.h"

using namespace std;


/* Th�m 1 Nh�n Vi�n v�o danh s�ch Nh�n Vi�n*/
void AddNV(NodeNV* Head, NhanVien* tempNV, int Ma)
{
	string MaNV = "NV" + convertInttoString(Ma);
	NodeNV* newNode = new NodeNV();
	tempNV->MaNV = MaNV;
	newNode->nv = tempNV;
	newNode->next = Head;
	newNode->prev = Head->prev;
	Head->prev = newNode;
	(newNode->prev)->next = newNode;
}
