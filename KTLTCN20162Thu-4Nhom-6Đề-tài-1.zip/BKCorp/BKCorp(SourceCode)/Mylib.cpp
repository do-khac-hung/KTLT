﻿#include <iostream>
#include <fstream>
#include <conio.h>
#include <windows.h>
#include <string>
#include "Mylib.h"
using namespace std;

/* Khởi tạo các danh sách liên kết lưu trữ nhân viên*/
void Init(NodeNV* Head, NodeCT* HeadCT)
{
	Head->next = Head;
	Head->prev = Head;
	HeadCT->next = HeadCT;
	HeadCT->prev = HeadCT;
}


/* Chuyển 1 số sang 1 xâu tương ứng*/
string convertInttoString(int number)
{

	if (number == 0)
		return "0";
	string temp = "";
	string returnvalue = "";
	while (number>0)
	{
		temp += number % 10 + 48;
		number /= 10;
	}
	for (int i = 0; i < temp.length(); i++)
		returnvalue += temp[temp.length() - i - 1];
	return returnvalue;
}

/* Chuyển tất cả kí tự in hoa sang in thường*/
string toLower(string str)
{
	int c;
	string returnvalue = "";
	for (int i = 0; i < str.length(); i++)
	{
		c = (int)str[i];
		if (c >= 65 && c <= 90)
			c += 32;
		returnvalue += (char)c;
	}
	return returnvalue;
}


/* Kiểm tra 2 xâu có bằng nhau không*/
bool checkEquals(string s1, string s2)
{
	s1 = toLower(s1);
	s2 = toLower(s2);
	for (int i = 0; i < s1.length(); i++)
		if (s1[i] != s2[i]) {
			return false;
		}
	return true;
}

/* In ra thông tin của Nhân Viên*/
void printStaffInfo(NhanVien* staff)
{
	cout << staff->MaNV << endl;
	cout << staff->Ho << " " << staff->Ten << endl;
	cout << staff->Donvi << endl;
	cout << staff->Chucvu << endl;
	cout << staff->Ngaysinh << endl;
	cout << staff->Quequan << endl;
	cout << staff->Diachi << endl;
	cout << staff->Email << endl;
	cout << staff->Sdt << endl;
	cout << staff->Ngaybd << endl;
	for (int i = 0; i < staff->songaylam; i++)
		cout << staff->day[i] << endl;
	cout << "----------------------------------------------------" << endl;

}

/* In ra thông tin của 1 công ty con (phòng ban)*/
void printComanyInfo(NodeCT* CT)
{
	cout << CT->tenCT << " co " << CT->soluongNV << " nhan vien" << endl;
	cout << "Danh sach nhan vien trong cong ty " << endl;
	for (NodeNV* node_i = CT->staff->next; node_i != CT->staff;
		node_i = node_i->next)
		printStaffInfo(node_i->nv);
	cout << endl << endl;
}

/* Bảng chọn chức năng*/
void Menu()
{
	cout << "BANG CHON CHUC NANG: " << endl;
	cout << "1. Hien Thi Thong Tin " << endl;
	cout << "2. Tim Kiem Thong Tin " << endl;
	cout << "3. Hien Thi Tinh Trang Di lam cua Nhan Vien" << endl;
	cout << "4. Tim kiem thong tin cong ty " << endl;
	cout << "5. Them nhan vien vao cong ty" << endl;
	cout << "6. Cap nhat thong tin nhan vien" << endl;
	cout << "7. Thoat" << endl;
	cout << "Nhap Lua Chon: ";
}
